from interfaz import *

if __name__ == '__main__' :
    
    interfaz = Interfaz()
    interfaz.mainloop()
    
